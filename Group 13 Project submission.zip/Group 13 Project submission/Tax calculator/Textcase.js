


class bar_chart{
    constructor(width,height){
        this.width = width
        this.height = height
    }
    draw_main_title(content,title){
        content.font = "30px align"
        content.textBaseline = "middle"
        content.textAlign = "center"
        content.strokeText(title,this.width/2,15)
    }
    draw(content,x,n,h){
        content.fillStyle = "blue"
        content.fillRect(75 + x,  (this.height - h) - this.height/12,(this.width - 2*75)/n-1,h)

}
    draw_lines(content,height,width){
        content.fillStyle = "white"
        content.fillRect(50,height,width,1)
    }
    
    draw_line_numbers(content,word,height,width){
        content.textBaseline = "middle"
        content.textAlign = "center"
        content.font = "15px align"
        content.strokeText(word,40,height,width)
    }

    draw_title(content,word,width,height){
        var len = content.measureText(word).width;
        content.textBaseline = "middle"
        //content.textAlign = "center"
        content.font = "15px align"
        content.save()
        content.translate(75,0)
        content.strokeText(word, width,(11*height/12)+(height)/10)
        content.restore()
    }
    
}


